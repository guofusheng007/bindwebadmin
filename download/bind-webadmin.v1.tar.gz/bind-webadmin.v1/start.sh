cd /app
docker compose up -d
