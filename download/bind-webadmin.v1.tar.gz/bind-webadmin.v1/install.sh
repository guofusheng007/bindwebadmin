mkdir -p /app/mysql
cp -fr cert /app/

mkdir -p /app/server 
cp app.conf /app/server/
cp -fr env.txt /app/

cp docker-compose.yml /app/

