docker compose config -q   校验配置
docker compose up -d       启动项目
docker compose stop        停止
docker compose down        停止并删除
docker compose start       启动项目
docker compose restart     重启

docker system prune        删除不用的卷
--------------------------------------------
1。mysql和front中配置的NS_DOMAIN必须与后端app.conf中的配置的ns参数相同。
2。bind_mysql在初始化时，已写明数据库名称为BindDB,因此在后端及bind中的相应配置必须是为BindDB
3。后端app.conf中的服务端口9090已写入front中的nginx配置中，因此不能再更改。
4。docker-compose配置文件中的服务名称不要改改，已配置在相关配置文件中。

10.ip地址解析。若ns为test.com。
   则需要将如下3个A记录的解析到front前端所在的容器地址，通常为宿主地址
       test.com      A 192.168.1.7
       www.test.com  A 192.168.1.7
       api.test.com  A 192.168.1.7
   访问
      http://test.org
   默认帐号如下
      admin/admn1111mm
      demo/demo1111mm
   用户密码初始化
      update UserList set password=SHA2('guofs1111mm', 256) where id=7;
11.外部api接口
   http://ns_domain/ip
   http://ns_domain/json
   http://ns_domain/updatejson
   http://ns_domain/updateheader
   
